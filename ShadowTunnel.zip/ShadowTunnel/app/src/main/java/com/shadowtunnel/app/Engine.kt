package com.shadowtunnel.app

/**
 * Moteur de tunnel. Il crée lui-même l'interface TUN via ShadowVpnService.newBuilder().
 */
interface TunnelEngine {
    fun start(service: ShadowVpnService, link: String, settings: TunnelSettings)
    fun stop()
}

object EngineProvider {
    val engine: TunnelEngine = LibboxEngine()
}
