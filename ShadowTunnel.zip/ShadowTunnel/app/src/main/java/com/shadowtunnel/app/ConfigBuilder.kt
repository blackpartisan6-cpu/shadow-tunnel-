package com.shadowtunnel.app

import android.net.Uri
import android.util.Base64
import org.json.JSONArray
import org.json.JSONObject
import java.net.URLDecoder

/** Convertit un lien de partage (vless://, vmess://, ...) en configuration sing-box. */
object ConfigBuilder {

    fun build(link: String, s: TunnelSettings): String {
        val dns = s.dns
        val proxy = outbound(link).put("tag", "proxy")
        applyMux(proxy, s.mux)

        val config = JSONObject()
            .put("log", obj("level" to "warn"))
            .put(
                "dns", obj(
                    "servers" to JSONArray()
                        .put(obj("tag" to "remote", "address" to dns, "detour" to "proxy"))
                        .put(obj("tag" to "local", "address" to "local", "detour" to "direct")),
                    "rules" to JSONArray().put(obj("outbound" to "any", "server" to "local")),
                    "strategy" to "prefer_ipv4"
                )
            )
            .put(
                "inbounds", JSONArray().put(
                    obj(
                        "type" to "tun",
                        "tag" to "tun-in",
                        "inet4_address" to "172.19.0.1/30",
                        "inet6_address" to "fdfe:dcba:9876::1/126",
                        "mtu" to s.mtu,
                        "auto_route" to true,
                        "strict_route" to false,
                        "stack" to s.stack,
                        "sniff" to true
                    )
                )
            )
            .put(
                "outbounds", JSONArray()
                    .put(proxy)
                    .put(obj("type" to "direct", "tag" to "direct"))
                    .put(obj("type" to "block", "tag" to "block"))
                    .put(obj("type" to "dns", "tag" to "dns-out"))
            )
            .put(
                "route", obj(
                    "rules" to JSONArray().put(obj("protocol" to "dns", "outbound" to "dns-out")),
                    "auto_detect_interface" to true,
                    "final" to "proxy"
                )
            )
        return config.toString()
    }

    private fun outbound(link: String): JSONObject {
        return when (val scheme = link.substringBefore("://").lowercase()) {
            "vless" -> vless(link)
            "vmess" -> vmess(link)
            "trojan" -> trojan(link)
            "ss" -> shadowsocks(link)
            "hysteria2", "hy2" -> hysteria2(link)
            "tuic" -> tuic(link)
            "wireguard", "wg" -> wireguard(link)
            else -> throw IllegalArgumentException("Protocole non supporté : $scheme")
        }
    }

    // ------------------------------------------------------------ protocoles

    private fun vless(link: String): JSONObject {
        val u = Uri.parse(link.substringBefore('#'))
        val q = { k: String -> u.getQueryParameter(k)?.takeIf { it.isNotEmpty() } }
        val host = u.host ?: throw IllegalArgumentException("Lien vless invalide")
        return obj(
            "type" to "vless",
            "server" to host,
            "server_port" to port(u),
            "uuid" to u.userInfo,
            "flow" to q("flow"),
            "tls" to tls(q, host),
            "transport" to transport(q)
        )
    }

    private fun trojan(link: String): JSONObject {
        val u = Uri.parse(link.substringBefore('#'))
        val raw = { k: String -> u.getQueryParameter(k)?.takeIf { it.isNotEmpty() } }
        val q = { k: String -> if (k == "security") raw(k) ?: "tls" else raw(k) }
        val host = u.host ?: throw IllegalArgumentException("Lien trojan invalide")
        return obj(
            "type" to "trojan",
            "server" to host,
            "server_port" to port(u),
            "password" to u.userInfo,
            "tls" to tls(q, host),
            "transport" to transport(q)
        )
    }

    private fun vmess(link: String): JSONObject {
        val j = JSONObject(String(b64(link.substringAfter("://").substringBefore('#'))))
        val map = HashMap<String, String>()
        j.keys().forEach { k -> j.optString(k).takeIf { it.isNotEmpty() }?.let { map[k] = it } }
        // Aligne les clés vmess sur les paramètres communs
        map["type"] = map["net"] ?: "tcp"
        map["security"] = if (map["tls"] == "tls") "tls" else "none"
        val q = { k: String -> map[k] }
        val host = map["add"] ?: throw IllegalArgumentException("Lien vmess invalide")
        return obj(
            "type" to "vmess",
            "server" to host,
            "server_port" to (map["port"]?.toIntOrNull() ?: 443),
            "uuid" to map["id"],
            "alter_id" to (map["aid"]?.toIntOrNull() ?: 0),
            "security" to (map["scy"] ?: "auto"),
            "tls" to tls(q, host),
            "transport" to transport(q)
        )
    }

    private fun shadowsocks(link: String): JSONObject {
        val body = link.substringAfter("://").substringBefore('#').substringBefore('?')
        val decoded: String
        val hostPort: String
        if (body.contains('@')) {
            val info = body.substringBeforeLast('@')
            hostPort = body.substringAfterLast('@')
            decoded = if (info.contains(':')) URLDecoder.decode(info, "UTF-8") else String(b64(info))
        } else {
            val all = String(b64(body))
            decoded = all.substringBeforeLast('@')
            hostPort = all.substringAfterLast('@')
        }
        return obj(
            "type" to "shadowsocks",
            "server" to hostPort.substringBeforeLast(':'),
            "server_port" to (hostPort.substringAfterLast(':').toIntOrNull() ?: 8388),
            "method" to decoded.substringBefore(':'),
            "password" to decoded.substringAfter(':')
        )
    }

    private fun hysteria2(link: String): JSONObject {
        val u = Uri.parse(link.substringBefore('#'))
        val q = { k: String -> u.getQueryParameter(k)?.takeIf { it.isNotEmpty() } }
        val host = u.host ?: throw IllegalArgumentException("Lien hysteria2 invalide")
        val tls = obj("enabled" to true, "server_name" to (q("sni") ?: host))
        if (q("insecure") == "1") tls.put("insecure", true)
        val o = obj(
            "type" to "hysteria2",
            "server" to host,
            "server_port" to port(u),
            "password" to u.userInfo,
            "tls" to tls
        )
        q("obfs")?.let { o.put("obfs", obj("type" to it, "password" to q("obfs-password"))) }
        return o
    }

    private fun tuic(link: String): JSONObject {
        val u = Uri.parse(link.substringBefore('#'))
        val q = { k: String -> u.getQueryParameter(k)?.takeIf { it.isNotEmpty() } }
        val host = u.host ?: throw IllegalArgumentException("Lien tuic invalide")
        val info = u.userInfo ?: throw IllegalArgumentException("Lien tuic invalide (uuid:mot de passe)")
        val tls = obj(
            "enabled" to true,
            "server_name" to (q("sni") ?: host),
            "alpn" to JSONArray((q("alpn") ?: "h3").split(","))
        )
        if (q("allow_insecure") == "1" || q("insecure") == "1") tls.put("insecure", true)
        return obj(
            "type" to "tuic",
            "server" to host,
            "server_port" to port(u),
            "uuid" to info.substringBefore(':'),
            "password" to info.substringAfter(':', ""),
            "congestion_control" to (q("congestion_control") ?: "bbr"),
            "udp_relay_mode" to (q("udp_relay_mode") ?: "native"),
            "tls" to tls
        )
    }

    /** wireguard://CLE_PRIVEE@hote:port?publickey=...&address=10.0.0.2/32&mtu=1280&reserved=1,2,3 */
    private fun wireguard(link: String): JSONObject {
        val body = link.substringAfter("://").substringBefore('#')
        val query = body.substringAfter('?', "")
        val main = body.substringBefore('?')
        val privateKey = Uri.decode(main.substringBeforeLast('@'))
        val hostPort = main.substringAfterLast('@')
        val u = Uri.parse("wg://x/?$query")
        val q = { k: String -> u.getQueryParameter(k)?.takeIf { it.isNotEmpty() } }
        val peerKey = q("publickey") ?: q("peer_public_key")
            ?: throw IllegalArgumentException("Clé publique wireguard manquante")
        val addresses = (q("address") ?: "10.0.0.2/32").split(",").map { it.trim() }.filter { it.isNotEmpty() }
        val o = obj(
            "type" to "wireguard",
            "server" to hostPort.substringBeforeLast(':'),
            "server_port" to (hostPort.substringAfterLast(':').toIntOrNull() ?: 51820),
            "local_address" to JSONArray(addresses),
            "private_key" to privateKey,
            "peer_public_key" to peerKey,
            "pre_shared_key" to (q("presharedkey") ?: q("psk")),
            "mtu" to (q("mtu")?.toIntOrNull() ?: 1280)
        )
        q("reserved")?.let { r ->
            val nums = r.split(",").mapNotNull { it.trim().toIntOrNull() }
            if (nums.size == 3) o.put("reserved", JSONArray(nums))
        }
        return o
    }

    // ------------------------------------------------------------ communs

    /** Multiplexage h2mux (le serveur doit le supporter) ; ignoré avec XTLS Vision. */
    private fun applyMux(o: JSONObject, enabled: Boolean) {
        if (!enabled) return
        val type = o.optString("type")
        if (type !in setOf("vless", "vmess", "trojan", "shadowsocks")) return
        if (o.has("flow")) return
        o.put(
            "multiplex",
            obj("enabled" to true, "protocol" to "h2mux", "max_connections" to 4, "min_streams" to 4, "padding" to false)
        )
    }

    private fun tls(q: (String) -> String?, defaultSni: String): JSONObject? {
        val sec = q("security")?.lowercase()
        if (sec != "tls" && sec != "reality") return null
        val t = obj("enabled" to true, "server_name" to (q("sni") ?: q("host") ?: defaultSni))
        if (q("allowInsecure") == "1" || q("insecure") == "1") t.put("insecure", true)
        q("alpn")?.let { t.put("alpn", JSONArray(it.split(","))) }
        val fp = q("fp")
        if (fp != null || sec == "reality") {
            t.put("utls", obj("enabled" to true, "fingerprint" to (fp ?: "chrome")))
        }
        if (sec == "reality") {
            t.put("reality", obj("enabled" to true, "public_key" to q("pbk"), "short_id" to (q("sid") ?: "")))
        }
        return t
    }

    private fun transport(q: (String) -> String?): JSONObject? = when (q("type")?.lowercase()) {
        "ws" -> obj(
            "type" to "ws",
            "path" to (q("path") ?: "/"),
            "headers" to obj("Host" to q("host"))
        )
        "grpc" -> obj("type" to "grpc", "service_name" to q("serviceName"))
        "httpupgrade" -> obj("type" to "httpupgrade", "path" to (q("path") ?: "/"), "host" to q("host"))
        else -> null
    }

    private fun port(u: Uri): Int = if (u.port > 0) u.port else 443

    private fun obj(vararg pairs: Pair<String, Any?>): JSONObject {
        val o = JSONObject()
        for ((k, v) in pairs) if (v != null) o.put(k, v)
        return o
    }

    private fun b64(s: String): ByteArray {
        var t = s.trim().replace('-', '+').replace('_', '/')
        while (t.length % 4 != 0) t += "="
        return Base64.decode(t, Base64.DEFAULT)
    }
}
