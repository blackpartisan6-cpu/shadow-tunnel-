package com.shadowtunnel.app

import android.content.Context
import android.net.Uri
import android.util.Base64
import org.json.JSONArray
import org.json.JSONObject
import java.net.URLDecoder
import java.util.UUID

data class Profile(val id: String, val name: String, val protocol: String, val link: String)

object ProfileParser {
    private val schemes = setOf("vless", "vmess", "trojan", "ss", "hysteria2", "hy2", "tuic", "wireguard")

    fun parseAll(text: String): List<Profile> =
        text.split(Regex("\\s+")).mapNotNull { parse(it) }

    fun parse(raw: String): Profile? {
        val t = raw.trim()
        val scheme = t.substringBefore("://", "").lowercase()
        if (scheme !in schemes) return null

        var name = t.substringAfter('#', "")
        name = runCatching { URLDecoder.decode(name, "UTF-8") }.getOrDefault(name)

        if (name.isBlank() && scheme == "vmess") {
            name = runCatching {
                val json = String(Base64.decode(t.substringAfter("://"), Base64.DEFAULT))
                JSONObject(json).optString("ps")
            }.getOrDefault("")
        }
        if (name.isBlank()) {
            name = runCatching { Uri.parse(t).host }.getOrNull() ?: scheme.uppercase()
        }
        return Profile(UUID.randomUUID().toString(), name, scheme.uppercase(), t)
    }
}

class ProfileStore(context: Context) {
    private val prefs = context.getSharedPreferences("shadow_tunnel", Context.MODE_PRIVATE)

    fun load(): List<Profile> {
        val raw = prefs.getString("profiles", "[]") ?: "[]"
        return runCatching {
            val arr = JSONArray(raw)
            (0 until arr.length()).map {
                val o = arr.getJSONObject(it)
                Profile(o.getString("id"), o.getString("name"), o.getString("protocol"), o.getString("link"))
            }
        }.getOrDefault(emptyList())
    }

    fun save(list: List<Profile>) {
        val arr = JSONArray()
        list.forEach {
            arr.put(JSONObject().put("id", it.id).put("name", it.name).put("protocol", it.protocol).put("link", it.link))
        }
        prefs.edit().putString("profiles", arr.toString()).apply()
    }

    var selectedId: String?
        get() = prefs.getString("selected", null)
        set(v) { prefs.edit().putString("selected", v).apply() }

    var dns: String
        get() = prefs.getString("dns", "1.1.1.1") ?: "1.1.1.1"
        set(v) { prefs.edit().putString("dns", v).apply() }

    var mtu: Int
        get() = prefs.getInt("mtu", 9000)
        set(v) { prefs.edit().putInt("mtu", v).apply() }

    /** Pile réseau du TUN : mixed (rapide, recommandé), system ou gvisor. */
    var stack: String
        get() = prefs.getString("stack", "mixed") ?: "mixed"
        set(v) { prefs.edit().putString("stack", v).apply() }

    var mux: Boolean
        get() = prefs.getBoolean("mux", false)
        set(v) { prefs.edit().putBoolean("mux", v).apply() }

    /** Applications qui contournent le VPN. */
    var excluded: Set<String>
        get() = prefs.getStringSet("excluded", emptySet()) ?: emptySet()
        set(v) { prefs.edit().putStringSet("excluded", v.toSet()).apply() }

    fun settings() = TunnelSettings(dns, mtu, stack, mux, excluded)
}

data class TunnelSettings(
    val dns: String,
    val mtu: Int,
    val stack: String,
    val mux: Boolean,
    val bypass: Set<String>
)
