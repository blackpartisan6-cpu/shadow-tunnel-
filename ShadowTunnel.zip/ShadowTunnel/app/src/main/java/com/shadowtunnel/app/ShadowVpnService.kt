package com.shadowtunnel.app

import android.content.Intent
import android.net.TrafficStats
import android.net.VpnService
import android.os.Handler
import android.os.Looper
import android.os.Process

class ShadowVpnService : VpnService() {

    private val handler = Handler(Looper.getMainLooper())
    private var baseTx = 0L
    private var baseRx = 0L
    private var lastTx = 0L
    private var lastRx = 0L

    private val ticker = object : Runnable {
        override fun run() {
            // Trafic réel du tunnel = octets échangés par l'application avec le serveur
            val tx = (TrafficStats.getUidTxBytes(Process.myUid()) - baseTx).coerceAtLeast(0)
            val rx = (TrafficStats.getUidRxBytes(Process.myUid()) - baseRx).coerceAtLeast(0)
            VpnState.upSpeed.value = (tx - lastTx).coerceAtLeast(0)
            VpnState.downSpeed.value = (rx - lastRx).coerceAtLeast(0)
            lastTx = tx
            lastRx = rx
            VpnState.upBytes.value = tx
            VpnState.downBytes.value = rx
            handler.postDelayed(this, 1000)
        }
    }

    /** Utilisé par le moteur pour créer l'interface TUN. */
    fun newBuilder(): Builder = Builder()

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            stopTunnel()
            return START_NOT_STICKY
        }
        val link = intent?.getStringExtra(EXTRA_LINK)
        if (link == null) {
            stopSelf()
            return START_NOT_STICKY
        }
        startTunnel(link, ProfileStore(this).settings())
        return START_NOT_STICKY
    }

    private fun startTunnel(link: String, settings: TunnelSettings) {
        VpnState.status.value = Status.Connecting
        VpnState.message.value = null
        Thread {
            try {
                EngineProvider.engine.start(this, link, settings)
                baseTx = TrafficStats.getUidTxBytes(Process.myUid())
                baseRx = TrafficStats.getUidRxBytes(Process.myUid())
                lastTx = 0L
                lastRx = 0L
                VpnState.since.value = System.currentTimeMillis()
                VpnState.status.value = Status.Connected
                handler.post(ticker)
            } catch (e: Throwable) {
                fail(e.message ?: "Échec de la connexion")
            }
        }.start()
    }

    private fun release() {
        handler.removeCallbacks(ticker)
        runCatching { EngineProvider.engine.stop() }
        VpnState.upBytes.value = 0
        VpnState.downBytes.value = 0
        VpnState.upSpeed.value = 0
        VpnState.downSpeed.value = 0
    }

    private fun stopTunnel() {
        release()
        VpnState.status.value = Status.Disconnected
        stopSelf()
    }

    private fun fail(msg: String) {
        release()
        VpnState.message.value = msg
        VpnState.status.value = Status.Error
        stopSelf()
    }

    override fun onRevoke() {
        stopTunnel()
        super.onRevoke()
    }

    override fun onDestroy() {
        release()
        if (VpnState.status.value != Status.Error) VpnState.status.value = Status.Disconnected
        super.onDestroy()
    }

    companion object {
        const val ACTION_STOP = "com.shadowtunnel.app.STOP"
        const val EXTRA_LINK = "link"
    }
}
