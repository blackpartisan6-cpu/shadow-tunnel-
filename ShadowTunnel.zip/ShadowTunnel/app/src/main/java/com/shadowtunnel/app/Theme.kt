package com.shadowtunnel.app

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

val Bg = Color(0xFF07030F)
val BgDeep = Color(0xFF1A0838)
val CardBg = Color(0xFF140A2A)
val Violet = Color(0xFF9B30FF)
val VioletDark = Color(0xFF6A1BFF)
val Lavender = Color(0xFFD9C8FF)
val TextDim = Color(0xFF9C8FBF)
val Danger = Color(0xFFFF4D6D)

@Composable
fun ShadowTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = Violet,
            onPrimary = Color.White,
            secondary = VioletDark,
            background = Bg,
            onBackground = Color.White,
            surface = CardBg,
            onSurface = Color.White,
            surfaceVariant = CardBg,
            onSurfaceVariant = TextDim,
            outline = Color(0xFF3B2870),
            error = Danger
        ),
        content = content
    )
}
