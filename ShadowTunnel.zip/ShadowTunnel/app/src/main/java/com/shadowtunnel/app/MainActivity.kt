package com.shadowtunnel.app

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.net.VpnService
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.List
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Menu
import androidx.compose.material.icons.filled.KeyboardArrowDown
import androidx.compose.material.icons.filled.KeyboardArrowUp
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import java.util.Locale

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent { ShadowTheme { App() } }
    }
}

@Composable
fun App(vm: MainViewModel = viewModel()) {
    var tab by rememberSaveable { mutableIntStateOf(0) }
    Box(
        Modifier
            .fillMaxSize()
            .background(Brush.verticalGradient(listOf(Bg, BgDeep)))
    ) {
        Scaffold(
            containerColor = Color.Transparent,
            bottomBar = {
                NavigationBar(containerColor = Color(0xCC0A0414)) {
                    val items = listOf(
                        Triple("Accueil", Icons.Filled.Home, 0),
                        Triple("Profils", Icons.AutoMirrored.Filled.List, 1),
                        Triple("Apps", Icons.Filled.Menu, 2),
                        Triple("Réglages", Icons.Filled.Settings, 3)
                    )
                    items.forEach { (label, icon, i) ->
                        NavigationBarItem(
                            selected = tab == i,
                            onClick = { tab = i },
                            icon = { Icon(icon, contentDescription = label) },
                            label = { Text(label) },
                            colors = NavigationBarItemDefaults.colors(
                                selectedIconColor = Color.White,
                                selectedTextColor = Violet,
                                indicatorColor = VioletDark,
                                unselectedIconColor = TextDim,
                                unselectedTextColor = TextDim
                            )
                        )
                    }
                }
            }
        ) { inner ->
            Box(Modifier.padding(inner).statusBarsPadding()) {
                when (tab) {
                    0 -> HomeScreen(vm, onGoProfiles = { tab = 1 })
                    1 -> ProfilesScreen(vm)
                    2 -> AppsScreen(vm)
                    else -> SettingsScreen(vm)
                }
            }
        }
    }
}

// ---------------------------------------------------------------- Accueil

@Composable
fun HomeScreen(vm: MainViewModel, onGoProfiles: () -> Unit) {
    val ctx = LocalContext.current
    val status by VpnState.status.collectAsState()
    val message by VpnState.message.collectAsState()
    val since by VpnState.since.collectAsState()
    val up by VpnState.upBytes.collectAsState()
    val down by VpnState.downBytes.collectAsState()
    val upSpeed by VpnState.upSpeed.collectAsState()
    val downSpeed by VpnState.downSpeed.collectAsState()
    val profiles by vm.profiles.collectAsState()
    val selectedId by vm.selectedId.collectAsState()
    val profile = profiles.firstOrNull { it.id == selectedId }

    var now by remember { mutableLongStateOf(System.currentTimeMillis()) }
    LaunchedEffect(status) {
        while (status == Status.Connected) {
            now = System.currentTimeMillis()
            delay(1000)
        }
    }

    val vpnLauncher = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { r ->
        if (r.resultCode == Activity.RESULT_OK && profile != null) startVpn(ctx, vm, profile)
    }

    fun toggle() {
        if (status == Status.Connected || status == Status.Connecting) {
            ctx.startService(Intent(ctx, ShadowVpnService::class.java).setAction(ShadowVpnService.ACTION_STOP))
        } else if (profile == null) {
            onGoProfiles()
        } else {
            val prep = VpnService.prepare(ctx)
            if (prep != null) vpnLauncher.launch(prep) else startVpn(ctx, vm, profile)
        }
    }

    Column(
        Modifier.fillMaxSize().padding(horizontal = 20.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Header()
        Spacer(Modifier.weight(1f))

        PowerButton(status, onClick = ::toggle)
        Spacer(Modifier.height(24.dp))

        val (label, color) = when (status) {
            Status.Connected -> "PROTÉGÉ" to Violet
            Status.Connecting -> "CONNEXION…" to Lavender
            Status.Error -> "ERREUR" to Danger
            Status.Disconnected -> "DÉCONNECTÉ" to TextDim
        }
        Text(label, color = color, fontSize = 22.sp, fontWeight = FontWeight.Black, letterSpacing = 3.sp)
        Spacer(Modifier.height(6.dp))
        Text(
            when {
                status == Status.Connected -> formatDuration(now - since)
                status == Status.Error && message != null -> message!!
                else -> "Touchez pour vous connecter"
            },
            color = if (status == Status.Error) Danger else TextDim,
            textAlign = TextAlign.Center,
            fontSize = 14.sp
        )

        Spacer(Modifier.weight(1f))

        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            StatCard("Téléchargement", formatBytes(down), formatBytes(downSpeed) + "/s", Icons.Filled.KeyboardArrowDown, Modifier.weight(1f))
            StatCard("Envoi", formatBytes(up), formatBytes(upSpeed) + "/s", Icons.Filled.KeyboardArrowUp, Modifier.weight(1f))
        }
        Spacer(Modifier.height(12.dp))
        ProfileCard(profile, onClick = onGoProfiles)
        Spacer(Modifier.height(16.dp))
    }
}

private fun startVpn(ctx: Context, vm: MainViewModel, p: Profile) {
    ctx.startService(Intent(ctx, ShadowVpnService::class.java).putExtra(ShadowVpnService.EXTRA_LINK, p.link))
}

@Composable
fun Header() {
    Row(
        Modifier.fillMaxWidth().padding(top = 12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Image(
            painterResource(R.drawable.logo),
            contentDescription = null,
            modifier = Modifier.size(44.dp).clip(RoundedCornerShape(12.dp))
        )
        Spacer(Modifier.width(12.dp))
        Text("SHADOW ", color = Color.White, fontWeight = FontWeight.Black, fontStyle = FontStyle.Italic, fontSize = 22.sp)
        Text("TUNNEL", color = Violet, fontWeight = FontWeight.Black, fontStyle = FontStyle.Italic, fontSize = 22.sp)
    }
}

@Composable
fun PowerButton(status: Status, onClick: () -> Unit) {
    // L'animation n'existe que pendant la connexion (économie de batterie)
    val pulse: State<Float> = if (status == Status.Connecting) {
        rememberInfiniteTransition(label = "pulse").animateFloat(
            initialValue = 0.9f,
            targetValue = 1.12f,
            animationSpec = infiniteRepeatable(tween(900, easing = FastOutSlowInEasing), RepeatMode.Reverse),
            label = "p"
        )
    } else {
        remember { mutableStateOf(1f) }
    }
    val color = when (status) {
        Status.Connected -> Violet
        Status.Connecting -> Lavender
        Status.Error -> Danger
        Status.Disconnected -> Color(0xFF4A3A78)
    }

    Box(
        Modifier.size(230.dp).clip(CircleShape).clickable(onClick = onClick),
        contentAlignment = Alignment.Center
    ) {
        Canvas(Modifier.fillMaxSize()) {
            val glow = pulse.value
            val c = center
            val r = size.minDimension / 2
            if (status != Status.Disconnected) {
                drawCircle(
                    brush = Brush.radialGradient(
                        colors = listOf(color.copy(alpha = 0.5f), Color.Transparent),
                        center = c,
                        radius = r * glow
                    ),
                    radius = r
                )
            }
            drawCircle(Color(0xFF0E0620), radius = r * 0.68f)
            drawCircle(color, radius = r * 0.68f, style = Stroke(width = 6.dp.toPx()))
            drawCircle(color.copy(alpha = 0.3f), radius = r * 0.78f, style = Stroke(width = 2.dp.toPx()))

            val ar = r * 0.28f
            drawArc(
                color = color,
                startAngle = -50f,
                sweepAngle = 280f,
                useCenter = false,
                topLeft = Offset(c.x - ar, c.y - ar),
                size = Size(ar * 2, ar * 2),
                style = Stroke(width = 9.dp.toPx(), cap = StrokeCap.Round)
            )
            drawLine(
                color = color,
                start = Offset(c.x, c.y - ar * 1.2f),
                end = Offset(c.x, c.y - ar * 0.1f),
                strokeWidth = 9.dp.toPx(),
                cap = StrokeCap.Round
            )
        }
    }
}

@Composable
fun StatCard(title: String, value: String, sub: String, icon: androidx.compose.ui.graphics.vector.ImageVector, modifier: Modifier) {
    Row(
        modifier
            .clip(RoundedCornerShape(18.dp))
            .background(CardBg)
            .border(1.dp, MaterialTheme.colorScheme.outline, RoundedCornerShape(18.dp))
            .padding(14.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(icon, null, tint = Violet)
        Spacer(Modifier.width(8.dp))
        Column {
            Text(title, color = TextDim, fontSize = 11.sp)
            Text(value, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 16.sp)
            Text(sub, color = Violet, fontSize = 11.sp)
        }
    }
}

@Composable
fun ProfileCard(profile: Profile?, onClick: () -> Unit) {
    Row(
        Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(18.dp))
            .background(CardBg)
            .border(1.dp, Violet.copy(alpha = 0.6f), RoundedCornerShape(18.dp))
            .clickable(onClick = onClick)
            .padding(16.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(Modifier.weight(1f)) {
            Text("Profil actif", color = TextDim, fontSize = 11.sp)
            Text(profile?.name ?: "Aucun profil — touchez pour en ajouter", color = Color.White, fontWeight = FontWeight.Bold)
        }
        if (profile != null) {
            Text(profile.protocol, color = Violet, fontWeight = FontWeight.Black, fontSize = 12.sp)
        }
    }
}

// ---------------------------------------------------------------- Profils

@Composable
fun ProfilesScreen(vm: MainViewModel) {
    val profiles by vm.profiles.collectAsState()
    val selectedId by vm.selectedId.collectAsState()
    var showAdd by remember { mutableStateOf(false) }

    Column(Modifier.fillMaxSize().padding(horizontal = 20.dp)) {
        Row(Modifier.fillMaxWidth().padding(top = 16.dp, bottom = 12.dp), verticalAlignment = Alignment.CenterVertically) {
            Text("Profils", color = Color.White, fontSize = 26.sp, fontWeight = FontWeight.Black, modifier = Modifier.weight(1f))
            Button(
                onClick = { showAdd = true },
                colors = ButtonDefaults.buttonColors(containerColor = Violet)
            ) {
                Icon(Icons.Filled.Add, null)
                Spacer(Modifier.width(4.dp))
                Text("Ajouter")
            }
        }
        if (profiles.isEmpty()) {
            Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                Text(
                    "Aucun profil.\nCollez un lien vless://, vmess://, trojan://, ss://, hysteria2://…",
                    color = TextDim, textAlign = TextAlign.Center
                )
            }
        } else {
            LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp), contentPadding = PaddingValues(bottom = 16.dp)) {
                items(profiles, key = { it.id }) { p ->
                    val selected = p.id == selectedId
                    Row(
                        Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(16.dp))
                            .background(CardBg)
                            .border(
                                if (selected) 2.dp else 1.dp,
                                if (selected) Violet else MaterialTheme.colorScheme.outline,
                                RoundedCornerShape(16.dp)
                            )
                            .clickable { vm.select(p.id) }
                            .padding(start = 16.dp, top = 8.dp, bottom = 8.dp, end = 4.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(Modifier.weight(1f)) {
                            Text(p.name, color = Color.White, fontWeight = FontWeight.Bold, maxLines = 1)
                            Text(p.protocol, color = Violet, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                        }
                        IconButton(onClick = { vm.delete(p.id) }) {
                            Icon(Icons.Filled.Delete, "Supprimer", tint = TextDim)
                        }
                    }
                }
            }
        }
    }

    if (showAdd) AddProfileDialog(vm, onDismiss = { showAdd = false })
}

@Composable
fun AddProfileDialog(vm: MainViewModel, onDismiss: () -> Unit) {
    var text by remember { mutableStateOf("") }
    var error by remember { mutableStateOf<String?>(null) }
    val clipboard = LocalClipboardManager.current

    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = CardBg,
        title = { Text("Ajouter un profil", color = Color.White) },
        text = {
            Column {
                OutlinedTextField(
                    value = text,
                    onValueChange = { text = it; error = null },
                    placeholder = { Text("vless://…  (un lien par ligne)") },
                    minLines = 3,
                    maxLines = 6,
                    isError = error != null,
                    supportingText = error?.let { { Text(it) } },
                    modifier = Modifier.fillMaxWidth()
                )
                TextButton(onClick = { clipboard.getText()?.text?.let { text = it } }) {
                    Text("Coller depuis le presse-papiers", color = Violet)
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    if (vm.import(text) > 0) onDismiss() else error = "Aucun lien valide trouvé"
                },
                colors = ButtonDefaults.buttonColors(containerColor = Violet)
            ) { Text("Importer") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Annuler", color = TextDim) } }
    )
}

// ---------------------------------------------------------------- Réglages

@Composable
fun SettingsScreen(vm: MainViewModel) {
    val dns by vm.dns.collectAsState()
    val mtu by vm.mtu.collectAsState()
    val stack by vm.stack.collectAsState()
    val mux by vm.mux.collectAsState()
    var mtuText by remember { mutableStateOf(mtu.toString()) }

    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 20.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        Text("Réglages", color = Color.White, fontSize = 26.sp, fontWeight = FontWeight.Black, modifier = Modifier.padding(top = 16.dp))

        OutlinedTextField(
            value = dns,
            onValueChange = { vm.setDns(it.trim()) },
            label = { Text("Serveur DNS") },
            singleLine = true,
            modifier = Modifier.fillMaxWidth()
        )
        OutlinedTextField(
            value = mtuText,
            onValueChange = { s ->
                mtuText = s.filter { it.isDigit() }.take(4)
                mtuText.toIntOrNull()?.let { vm.setMtu(it.coerceIn(1280, 9000)) }
            },
            label = { Text("MTU (1280 – 9000)") },
            singleLine = true,
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
            modifier = Modifier.fillMaxWidth()
        )

        Text("Pile réseau", color = Color.White, fontWeight = FontWeight.Bold)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            listOf("mixed", "system", "gvisor").forEach { name ->
                FilterChip(
                    selected = stack == name,
                    onClick = { vm.setStack(name) },
                    label = { Text(name) },
                    colors = FilterChipDefaults.filterChipColors(
                        selectedContainerColor = VioletDark,
                        selectedLabelColor = Color.White
                    )
                )
            }
        }
        Text("mixed : le plus rapide (recommandé). Changez seulement en cas de problème.", color = TextDim, fontSize = 12.sp)

        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text("Multiplexage", color = Color.White, fontWeight = FontWeight.Bold)
                Text("Plusieurs connexions sur un seul tunnel. À activer seulement si votre serveur le supporte.", color = TextDim, fontSize = 12.sp)
            }
            Switch(
                checked = mux,
                onCheckedChange = { vm.setMux(it) },
                colors = SwitchDefaults.colors(checkedTrackColor = Violet)
            )
        }

        Text("Les réglages s'appliquent à la prochaine connexion.", color = TextDim, fontSize = 12.sp)
        Spacer(Modifier.height(8.dp))
        Text(
            "SHADOW TUNNEL  v1.0",
            color = TextDim, fontSize = 12.sp,
            modifier = Modifier.align(Alignment.CenterHorizontally)
        )
        Spacer(Modifier.height(16.dp))
    }
}

// ---------------------------------------------------------------- Apps (contournement)

data class AppInfo(val pkg: String, val label: String)

fun loadApps(ctx: Context): List<AppInfo> {
    val pm = ctx.packageManager
    val intent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
    return pm.queryIntentActivities(intent, 0)
        .map { AppInfo(it.activityInfo.packageName, it.loadLabel(pm).toString()) }
        .distinctBy { it.pkg }
        .filter { it.pkg != ctx.packageName }
        .sortedBy { it.label.lowercase() }
}

@Composable
fun AppsScreen(vm: MainViewModel) {
    val ctx = LocalContext.current
    val excluded by vm.excluded.collectAsState()
    var apps by remember { mutableStateOf<List<AppInfo>?>(null) }
    var query by remember { mutableStateOf("") }

    LaunchedEffect(Unit) { apps = withContext(Dispatchers.Default) { loadApps(ctx) } }

    Column(Modifier.fillMaxSize().padding(horizontal = 20.dp)) {
        Text("Applications", color = Color.White, fontSize = 26.sp, fontWeight = FontWeight.Black, modifier = Modifier.padding(top = 16.dp))
        Text(
            "Les applications cochées contournent le VPN (connexion directe). ${excluded.size} sélectionnée(s). Pris en compte à la prochaine connexion.",
            color = TextDim, fontSize = 12.sp, modifier = Modifier.padding(vertical = 6.dp)
        )
        OutlinedTextField(
            value = query,
            onValueChange = { query = it },
            placeholder = { Text("Rechercher") },
            singleLine = true,
            modifier = Modifier.fillMaxWidth()
        )
        Spacer(Modifier.height(8.dp))

        val list = apps
        if (list == null) {
            Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                CircularProgressIndicator(color = Violet)
            }
        } else {
            val shown = remember(list, query) {
                list.filter { query.isBlank() || it.label.contains(query, true) || it.pkg.contains(query, true) }
            }
            LazyColumn(contentPadding = PaddingValues(bottom = 16.dp)) {
                items(shown, key = { it.pkg }) { a ->
                    Row(
                        Modifier.fillMaxWidth().clickable { vm.toggleExcluded(a.pkg) }.padding(vertical = 4.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Checkbox(
                            checked = a.pkg in excluded,
                            onCheckedChange = { vm.toggleExcluded(a.pkg) },
                            colors = CheckboxDefaults.colors(checkedColor = Violet)
                        )
                        Column {
                            Text(a.label, color = Color.White, maxLines = 1)
                            Text(a.pkg, color = TextDim, fontSize = 11.sp, maxLines = 1)
                        }
                    }
                }
            }
        }
    }
}

// ---------------------------------------------------------------- Utilitaires

fun formatDuration(ms: Long): String {
    val s = (ms / 1000).coerceAtLeast(0)
    return String.format(Locale.US, "%02d:%02d:%02d", s / 3600, (s % 3600) / 60, s % 60)
}

fun formatBytes(b: Long): String = when {
    b < 1024 -> "$b B"
    b < 1024 * 1024 -> String.format(Locale.US, "%.1f KB", b / 1024.0)
    b < 1024L * 1024 * 1024 -> String.format(Locale.US, "%.1f MB", b / 1048576.0)
    else -> String.format(Locale.US, "%.2f GB", b / 1073741824.0)
}
