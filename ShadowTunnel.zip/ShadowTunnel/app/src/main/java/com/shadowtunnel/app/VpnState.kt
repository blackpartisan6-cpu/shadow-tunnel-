package com.shadowtunnel.app

import kotlinx.coroutines.flow.MutableStateFlow

enum class Status { Disconnected, Connecting, Connected, Error }

/** État partagé entre le service VPN et l'interface. */
object VpnState {
    val status = MutableStateFlow(Status.Disconnected)
    val message = MutableStateFlow<String?>(null)
    val since = MutableStateFlow(0L)
    val upBytes = MutableStateFlow(0L)
    val downBytes = MutableStateFlow(0L)
    val upSpeed = MutableStateFlow(0L)
    val downSpeed = MutableStateFlow(0L)
}
