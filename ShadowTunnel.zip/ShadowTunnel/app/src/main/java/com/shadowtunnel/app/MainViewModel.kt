package com.shadowtunnel.app

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import kotlinx.coroutines.flow.MutableStateFlow

class MainViewModel(app: Application) : AndroidViewModel(app) {
    private val store = ProfileStore(app)

    val profiles = MutableStateFlow(store.load())
    val selectedId = MutableStateFlow(store.selectedId)
    val dns = MutableStateFlow(store.dns)
    val mtu = MutableStateFlow(store.mtu)
    val stack = MutableStateFlow(store.stack)
    val mux = MutableStateFlow(store.mux)
    val excluded = MutableStateFlow(store.excluded)

    fun selected(): Profile? = profiles.value.firstOrNull { it.id == selectedId.value }

    /** Retourne le nombre de profils importés. */
    fun import(text: String): Int {
        val added = ProfileParser.parseAll(text)
        if (added.isEmpty()) return 0
        profiles.value = profiles.value + added
        store.save(profiles.value)
        if (selectedId.value == null) select(added.first().id)
        return added.size
    }

    fun select(id: String) {
        selectedId.value = id
        store.selectedId = id
    }

    fun delete(id: String) {
        profiles.value = profiles.value.filter { it.id != id }
        store.save(profiles.value)
        if (selectedId.value == id) {
            val next = profiles.value.firstOrNull()?.id
            selectedId.value = next
            store.selectedId = next
        }
    }

    fun setDns(v: String) { dns.value = v; store.dns = v }
    fun setMtu(v: Int) { mtu.value = v; store.mtu = v }
    fun setStack(v: String) { stack.value = v; store.stack = v }
    fun setMux(v: Boolean) { mux.value = v; store.mux = v }

    fun toggleExcluded(pkg: String) {
        val next = if (pkg in excluded.value) excluded.value - pkg else excluded.value + pkg
        excluded.value = next
        store.excluded = next
    }
}
