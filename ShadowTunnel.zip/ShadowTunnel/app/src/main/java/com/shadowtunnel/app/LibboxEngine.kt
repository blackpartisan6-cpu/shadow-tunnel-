package com.shadowtunnel.app

import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.net.NetworkRequest
import android.os.Build
import android.os.ParcelFileDescriptor
import android.util.Base64
import android.util.Log
import io.nekohasekai.libbox.BoxService
import io.nekohasekai.libbox.Libbox
import io.nekohasekai.libbox.PlatformInterface
import java.io.File
import java.lang.reflect.InvocationHandler
import java.lang.reflect.Proxy
import java.net.NetworkInterface
import java.security.KeyStore
import java.security.cert.X509Certificate

/**
 * Moteur basé sur libbox (sing-box).
 * L'interface "plateforme" est implémentée via un Proxy dynamique, par nom de méthode :
 * le code reste compatible quelle que soit la version exacte de libbox compilée.
 */
class LibboxEngine : TunnelEngine {

    private var box: BoxService? = null
    private var tun: ParcelFileDescriptor? = null
    private var callback: ConnectivityManager.NetworkCallback? = null
    private val certs: List<String> by lazy { systemCerts() }

    override fun start(service: ShadowVpnService, link: String, settings: TunnelSettings) {
        val ctx = service.applicationContext
        val work = File(ctx.filesDir, "work").apply { mkdirs() }
        libboxSetup(ctx.filesDir.absolutePath, work.absolutePath, ctx.cacheDir.absolutePath)

        val config = ConfigBuilder.build(link, settings)
        val cm = ctx.getSystemService(ConnectivityManager::class.java)

        val platform = Proxy.newProxyInstance(
            PlatformInterface::class.java.classLoader,
            arrayOf(PlatformInterface::class.java),
            InvocationHandler { proxy, m, args ->
                if (m.declaringClass == Any::class.java) return@InvocationHandler objMethod(proxy, m.name, args)
                when (m.name) {
                    "usePlatformAutoDetectInterfaceControl",
                    "usePlatformDefaultInterfaceMonitor",
                    "usePlatformInterfaceGetter" -> true

                    "autoDetectInterfaceControl" -> {
                        service.protect(args!![0] as Int)
                        null
                    }
                    "openTun" -> openTun(service, ctx.packageName, settings)
                    "writeLog" -> {
                        Log.i("libbox", args?.getOrNull(0)?.toString() ?: "")
                        null
                    }
                    "useProcFS" -> Build.VERSION.SDK_INT < Build.VERSION_CODES.Q
                    "startDefaultInterfaceMonitor" -> {
                        startMonitor(cm, args!![0]!!)
                        null
                    }
                    "closeDefaultInterfaceMonitor" -> {
                        stopMonitor(cm)
                        null
                    }
                    "getInterfaces" -> interfaces(m.returnType)
                    "systemCertificates" -> iterProxy(m.returnType, certs)
                    "findConnectionOwner", "packageNameByUid", "uidByPackageName" ->
                        throw UnsupportedOperationException()
                    else -> defaultFor(m.returnType)
                }
            }
        ) as PlatformInterface

        val s = Libbox.newService(config, platform)
        s.start()
        box = s
    }

    override fun stop() {
        runCatching { box?.close() }
        box = null
        runCatching { tun?.close() }
        tun = null
    }

    // ------------------------------------------------------------ setup

    /** Libbox.setup a deux signatures selon la version : on s'adapte. */
    private fun libboxSetup(base: String, work: String, tmp: String) {
        val m = Libbox::class.java.methods.first { it.name == "setup" }
        if (m.parameterTypes.size == 1) {
            val optCls = m.parameterTypes[0]
            val opt = optCls.getDeclaredConstructor().newInstance()
            fun set(name: String, v: Any) {
                optCls.methods.firstOrNull { it.name == name && it.parameterTypes.size == 1 }?.invoke(opt, v)
            }
            set("setBasePath", base)
            set("setWorkingPath", work)
            set("setTempPath", tmp)
            m.invoke(null, opt)
        } else {
            m.invoke(null, base, work, tmp, false)
        }
    }

    // ------------------------------------------------------------ TUN

    private fun openTun(service: ShadowVpnService, pkg: String, s: TunnelSettings): Int {
        val b = service.newBuilder()
            .setSession("SHADOW TUNNEL")
            .setMtu(s.mtu)
            .addAddress("172.19.0.1", 30)
            .addRoute("0.0.0.0", 0)
            .addAddress("fdfe:dcba:9876::1", 126)
            .addRoute("::", 0)
            .addDnsServer(s.dns)
        // L'application elle-même et les apps choisies contournent le VPN
        runCatching { b.addDisallowedApplication(pkg) }
        s.bypass.forEach { runCatching { b.addDisallowedApplication(it) } }
        val pfd = b.establish() ?: throw IllegalStateException("Permission VPN refusée")
        tun = pfd
        return pfd.fd
    }

    // ------------------------------------------------------------ réseau

    private fun startMonitor(cm: ConnectivityManager, listener: Any) {
        val request = NetworkRequest.Builder()
            .addCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
            .addCapability(NetworkCapabilities.NET_CAPABILITY_NOT_VPN)
            .build()
        val cb = object : ConnectivityManager.NetworkCallback() {
            override fun onAvailable(network: android.net.Network) = push(cm, listener)
            override fun onLost(network: android.net.Network) = push(cm, listener)
            override fun onLinkPropertiesChanged(network: android.net.Network, lp: android.net.LinkProperties) =
                push(cm, listener)
        }
        callback = cb
        cm.registerNetworkCallback(request, cb)
        push(cm, listener)
    }

    private fun stopMonitor(cm: ConnectivityManager) {
        callback?.let { runCatching { cm.unregisterNetworkCallback(it) } }
        callback = null
    }

    /** Signale à sing-box l'interface physique (Wi-Fi de préférence, sinon mobile). */
    @Suppress("DEPRECATION")
    private fun push(cm: ConnectivityManager, listener: Any) {
        val best = cm.allNetworks
            .mapNotNull { n -> cm.getNetworkCapabilities(n)?.let { n to it } }
            .filter { (_, c) ->
                c.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET) &&
                    !c.hasTransport(NetworkCapabilities.TRANSPORT_VPN)
            }
            .sortedBy { (_, c) ->
                if (c.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) ||
                    c.hasTransport(NetworkCapabilities.TRANSPORT_ETHERNET)
                ) 0 else 1
            }
            .firstOrNull()?.first ?: return
        val name = cm.getLinkProperties(best)?.interfaceName ?: return
        val index = runCatching { NetworkInterface.getByName(name)?.index }.getOrNull() ?: return
        runCatching {
            val m = listener.javaClass.methods.first { it.name == "updateDefaultInterface" }
            val params = mutableListOf<Any>(name, index)
            while (params.size < m.parameterTypes.size) params.add(false)
            m.invoke(listener, *params.toTypedArray())
        }.onFailure { Log.w("libbox", "updateDefaultInterface: $it") }
    }

    /** Liste des interfaces réseau pour sing-box (Android bloque l'accès netlink). */
    private fun interfaces(returnType: Class<*>): Any? = runCatching {
        val cls = Class.forName("io.nekohasekai.libbox.NetworkInterface")
        val list = NetworkInterface.getNetworkInterfaces()?.toList().orEmpty()
        val items = list.filter { runCatching { it.isUp }.getOrDefault(false) }.map { ni ->
            val o = cls.getDeclaredConstructor().newInstance()
            fun set(name: String, v: Any?) {
                if (v == null) return
                cls.methods.firstOrNull { it.name == name && it.parameterTypes.size == 1 }
                    ?.let { runCatching { it.invoke(o, v) } }
            }
            var flags = 1
            if (ni.isLoopback) flags = flags or 4
            if (ni.isPointToPoint) flags = flags or 8
            if (ni.supportsMulticast()) flags = flags or 16
            val n = ni.name
            val type = when {
                n.startsWith("wlan") -> "wifi"
                n.startsWith("rmnet") || n.startsWith("ccmni") || n.startsWith("v4-rmnet") -> "cellular"
                n.startsWith("eth") -> "ethernet"
                else -> "other"
            }
            val addrs = ni.interfaceAddresses.map {
                "${it.address.hostAddress?.substringBefore('%')}/${it.networkPrefixLength}"
            }
            set("setIndex", ni.index)
            set("setMTU", ni.mtu)
            set("setName", n)
            set("setFlags", flags)
            set("setType", type)
            set("setMetered", false)
            set("setAddresses", iterProxy(cls.methods.first { it.name == "getAddresses" }.returnType, addrs))
            set("setDNSServer", iterProxy(cls.methods.first { it.name == "getDNSServer" }.returnType, emptyList()))
            o
        }
        iterProxy(returnType, items)
    }.onFailure { Log.w("libbox", "getInterfaces: $it") }.getOrNull()

    // ------------------------------------------------------------ utilitaires

    private fun systemCerts(): List<String> = runCatching {
        val ks = KeyStore.getInstance("AndroidCAStore")
        ks.load(null, null)
        ks.aliases().toList().mapNotNull { alias ->
            (ks.getCertificate(alias) as? X509Certificate)?.let { c ->
                val body = Base64.encodeToString(c.encoded, Base64.NO_WRAP).chunked(64).joinToString("\n")
                "-----BEGIN CERTIFICATE-----\n$body\n-----END CERTIFICATE-----"
            }
        }
    }.getOrDefault(emptyList())

    /** Itérateur gomobile (hasNext / next / len) construit dynamiquement. */
    private fun iterProxy(type: Class<*>, items: List<Any?>): Any? {
        if (!type.isInterface) return null
        var i = 0
        return Proxy.newProxyInstance(
            type.classLoader, arrayOf(type),
            InvocationHandler { proxy, m, args ->
                if (m.declaringClass == Any::class.java) return@InvocationHandler objMethod(proxy, m.name, args)
                when (m.name) {
                    "len" -> items.size
                    "hasNext" -> i < items.size
                    "next" -> items[i++]
                    else -> defaultFor(m.returnType)
                }
            }
        )
    }

    private fun objMethod(p: Any, name: String, args: Array<Any?>?): Any? = when (name) {
        "hashCode" -> System.identityHashCode(p)
        "equals" -> p === args?.getOrNull(0)
        else -> "ShadowProxy"
    }

    private fun defaultFor(t: Class<*>): Any? = when (t) {
        java.lang.Boolean.TYPE -> false
        java.lang.Integer.TYPE -> 0
        java.lang.Long.TYPE -> 0L
        else -> null
    }
}
