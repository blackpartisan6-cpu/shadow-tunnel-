package com.shadowtunnel.app

import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.net.NetworkRequest
import android.os.ParcelFileDescriptor
import android.util.Log
import io.nekohasekai.libbox.BoxService
import io.nekohasekai.libbox.InterfaceUpdateListener
import io.nekohasekai.libbox.Libbox
import io.nekohasekai.libbox.NetworkInterfaceIterator
import io.nekohasekai.libbox.PlatformInterface
import io.nekohasekai.libbox.TunOptions
import io.nekohasekai.libbox.WIFIState
import java.io.File
import java.net.NetworkInterface

/** Moteur basé sur libbox (sing-box 1.10.x), compilé par le workflow GitHub. */
class LibboxEngine : TunnelEngine {

    private var box: BoxService? = null
    private var tun: ParcelFileDescriptor? = null
    private var callback: ConnectivityManager.NetworkCallback? = null

    override fun start(service: ShadowVpnService, link: String, settings: TunnelSettings) {
        val ctx = service.applicationContext
        val work = File(ctx.filesDir, "work").apply { mkdirs() }
        Libbox.setup(ctx.filesDir.absolutePath, work.absolutePath, ctx.cacheDir.absolutePath, false)

        val config = ConfigBuilder.build(link, settings)
        val cm = ctx.getSystemService(ConnectivityManager::class.java)

        val platform = object : PlatformInterface {
            override fun usePlatformAutoDetectInterfaceControl(): Boolean = true

            override fun autoDetectInterfaceControl(fd: Int) {
                service.protect(fd)
            }

            override fun openTun(options: TunOptions): Int {
                val b = service.newBuilder()
                    .setSession("SHADOW TUNNEL")
                    .setMtu(settings.mtu)
                    .addAddress("172.19.0.1", 30)
                    .addRoute("0.0.0.0", 0)
                    .addAddress("fdfe:dcba:9876::1", 126)
                    .addRoute("::", 0)
                    .addDnsServer(settings.dns)
                // L'application elle-même et les apps choisies contournent le VPN
                runCatching { b.addDisallowedApplication(ctx.packageName) }
                settings.bypass.forEach { runCatching { b.addDisallowedApplication(it) } }
                val pfd = b.establish() ?: throw IllegalStateException("Permission VPN refusée")
                tun = pfd
                return pfd.fd
            }

            override fun writeLog(message: String?) {
                Log.i("libbox", message ?: "")
            }

            override fun useProcFS(): Boolean = android.os.Build.VERSION.SDK_INT < android.os.Build.VERSION_CODES.Q

            override fun findConnectionOwner(
                ipProtocol: Int, sourceAddress: String?, sourcePort: Int,
                destinationAddress: String?, destinationPort: Int
            ): Int = throw UnsupportedOperationException()

            override fun packageNameByUid(uid: Int): String = throw UnsupportedOperationException()

            override fun uidByPackageName(packageName: String?): Int = throw UnsupportedOperationException()

            override fun usePlatformDefaultInterfaceMonitor(): Boolean = true

            override fun startDefaultInterfaceMonitor(listener: InterfaceUpdateListener) {
                val request = NetworkRequest.Builder()
                    .addCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
                    .addCapability(NetworkCapabilities.NET_CAPABILITY_NOT_VPN)
                    .build()
                val cb = object : ConnectivityManager.NetworkCallback() {
                    override fun onAvailable(network: android.net.Network) = push(cm, listener)
                    override fun onLost(network: android.net.Network) = push(cm, listener)
                    override fun onLinkPropertiesChanged(network: android.net.Network, lp: android.net.LinkProperties) =
                        push(cm, listener)
                }
                callback = cb
                cm.registerNetworkCallback(request, cb)
                push(cm, listener)
            }

            override fun closeDefaultInterfaceMonitor(listener: InterfaceUpdateListener) {
                callback?.let { runCatching { cm.unregisterNetworkCallback(it) } }
                callback = null
            }

            override fun usePlatformInterfaceGetter(): Boolean = false

            override fun getInterfaces(): NetworkInterfaceIterator = throw UnsupportedOperationException()

            override fun underNetworkExtension(): Boolean = false

            override fun includeAllNetworks(): Boolean = false

            override fun readWIFIState(): WIFIState? = null

            override fun clearDNSCache() {}
        }

        val s = Libbox.newService(config, platform)
        s.start()
        box = s
    }

    override fun stop() {
        runCatching { box?.close() }
        box = null
        runCatching { tun?.close() }
        tun = null
    }

    /** Signale à sing-box l'interface réseau physique (Wi-Fi de préférence, sinon mobile). */
    @Suppress("DEPRECATION")
    private fun push(cm: ConnectivityManager, listener: InterfaceUpdateListener) {
        val best = cm.allNetworks
            .mapNotNull { n -> cm.getNetworkCapabilities(n)?.let { n to it } }
            .filter { (_, c) ->
                c.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET) &&
                    !c.hasTransport(NetworkCapabilities.TRANSPORT_VPN)
            }
            .sortedBy { (_, c) ->
                if (c.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) ||
                    c.hasTransport(NetworkCapabilities.TRANSPORT_ETHERNET)
                ) 0 else 1
            }
            .firstOrNull()?.first ?: return
        val name = cm.getLinkProperties(best)?.interfaceName ?: return
        val index = runCatching { NetworkInterface.getByName(name)?.index }.getOrNull() ?: return
        listener.updateDefaultInterface(name, index)
    }
}
