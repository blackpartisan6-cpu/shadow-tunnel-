# SHADOW TUNNEL

Client VPN Android (Kotlin + Jetpack Compose) basé sur le noyau sing-box (libbox 1.10.x).

## Compiler avec GitHub
1. Pousse ce dossier sur un dépôt GitHub (branche `main`).
2. Onglet **Actions** > « Build SHADOW TUNNEL APK » : le workflow compile d'abord
   `libbox.aar` depuis sing-box, puis l'application.
3. Télécharge l'artefact `ShadowTunnel-apk`.

La première compilation prend ~10-15 min (compilation Go du noyau).

## Protocoles pris en charge
vless (tcp/ws/grpc/httpupgrade, tls, reality), vmess, trojan, shadowsocks, hysteria2, tuic, wireguard.

Format wireguard : `wireguard://CLE_PRIVEE@hote:port?publickey=...&address=10.0.0.2/32&mtu=1280&reserved=1,2,3#nom`

## Performance
- Pile réseau `mixed` (TCP système + UDP gVisor) par défaut, MTU 9000, IPv6 routé (pas de fuite).
- Multiplexage h2mux optionnel, contournement par application, animation active seulement pendant la connexion.
- APK séparés par architecture (arm64-v8a recommandé pour les téléphones récents) + APK universel.

## Si la compilation échoue
- Étape « Build libbox » : vérifier `SING_BOX_VERSION` / `GOMOBILE_VERSION` dans le workflow.
- Étape Gradle, erreurs dans `LibboxEngine.kt` : l'API libbox change entre versions de
  sing-box ; elle est écrite pour la 1.10.x.

## Compiler en local (Android Studio)
Compile `libbox.aar` (voir le workflow) et place-le dans `app/libs/`.
